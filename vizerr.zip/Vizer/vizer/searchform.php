<div class="searchBar">
    <div class="wrap">
        <form action="<?php echo home_url('/'); ?>" method="get">
            <input type="text" name="s" placeholder="Pesquise por filmes ou séries">
            <button type="submit"><i class="fa fa-search"></i></button>
        </form>
    </div>
</div>