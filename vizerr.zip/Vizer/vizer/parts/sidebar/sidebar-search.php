<div class="superSearch wow fadeInUp" data-wow-duration=".5s" data-wow-delay=".1s">
    <form action="<?php echo home_url('/'); ?>" method="get">
        <div class="sBar">
            <input type="text" name="s" placeholder="Pesquise por filmes, séries, animes ou atores">
            <button class="submitButton"><img src="<?php echo get_template_directory_uri() . '/assets/img/searchHome.png'; ?>" alt="series"></button>
        </div>
    </form>
</div>