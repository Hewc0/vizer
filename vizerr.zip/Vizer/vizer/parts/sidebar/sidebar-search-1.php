<div id="search-box">
    <div class="row">
        <h1>Pesquisar...</h1>
        <form action="<?php echo home_url('/'); ?>" method="get">
            <input type="text" name="s" placeholder="Pesquise por filmes, séries, animes ou atores">
            <button type="submit"><i class="fa fa-search"></i></button>
        </form>
    </div>
</div>