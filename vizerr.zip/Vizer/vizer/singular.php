<?php get_header();
the_post(); ?>
<div class="wrapper" id="faq-page">
    <br><br>
    <div class="clearfix"></div>
    <div class="row mini">
<?php the_content(); ?>
    </div>
    <br><br>
</div>
<?php get_footer(); ?>