<?php
define('WP_USE_THEMES', false);
require ('../../../../../wp-blog-header.php');
status_header(200);
nocache_headers();
set_time_limit(30000);
