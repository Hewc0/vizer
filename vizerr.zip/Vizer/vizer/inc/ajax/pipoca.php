<?php
// Our include
define('WP_USE_THEMES', false);
require_once('../../../../../wp-load.php');
?>
<div class="part">
	<img src="<?php echo get_template_directory_uri() . '/assets/img/movieNight.png'; ?>" alt="">
</div>
<div class="part">
	<div class="title">Ingredientes:</div>
	<ul>
		<li>1 xícara de milho para pipoca</li>
		<li>1 xícara de açúcar (branco ou amarelo)</li>
		<li>5 colheres de óleo</li>
	</ul>
</div>
<div class="part">
	<div class="title">Fazer pipoca:</div>
	<ul>
		<li>Adicione o milho e o óleo na panela em fogo baixo.</li>
		<li>Tampe e panela e espere alguns minutos.</li>
		<li>Segure a tampa para que a mesma não salte.</li>
		<li>Quando o milho parar de estourar, desligue o fogo porque está pronto.</li>
		<li>Reserve a pipoca fora da panela.</li>
	</ul>
</div>
<div class="part">
	<div class="title">Fazer caramelo:</div>
	<ul>
		<li>Adicione o açúcar na mesma panela em fogo baixo.</li>
		<li>Deixe o açúcar derreter.</li>
		<li>Mexa o açúcar sem parar para não queimar.</li>
		<li>Quando o açúcar ficar liquido, junte a pipoca e misture muito bem.</li>
		<li>Agora é só assistir um filme no <?php bloginfo('name'); ?>, e comer pipoca!</li>
	</ul>
</div>
